package com.company.application.domain;

public interface IPokerChipDistribution {

}
